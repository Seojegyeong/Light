import{n as e}from"./rolldown-runtime-Bh1tDfsg.js";import{_ as t,a as n,b as r,c as i,d as a,f as o,g as s,h as c,i as l,l as u,m as d,n as f,o as p,p as ee,r as m,s as h,t as g,u as _,v,y}from"./emotion-react-jsx-runtime.browser.esm-Cx6PoYX9.js";var b=e(r()),x=e(y(),1);function S(){return S=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},S.apply(null,arguments)}s();var te=function(e,t){var r=arguments;if(t==null||!i.call(t,`css`))return b.createElement.apply(void 0,r);var a=r.length,o=Array(a);o[0]=n,o[1]=h(e,t);for(var s=2;s<a;s++)o[s]=r[s];return b.createElement.apply(null,o)};(function(e){var t;t||=e.JSX||={}})(te||={});var ne=u(function(e,t){var n=e.styles,r=o([n],void 0,b.useContext(p)),i=b.useRef();return a(function(){var e=t.key+`-global`,n=new t.sheet.constructor({key:e,nonce:t.sheet.nonce,container:t.sheet.container,speedy:t.sheet.isSpeedy}),a=!1,o=document.querySelector(`style[data-emotion="`+e+` `+r.name+`"]`);return t.sheet.tags.length&&(n.before=t.sheet.tags[0]),o!==null&&(a=!0,o.setAttribute(`data-emotion`,e),n.hydrate([o])),i.current=[n,a],function(){n.flush()}},[t]),a(function(){var e=i.current,n=e[0];if(e[1]){e[1]=!1;return}r.next!==void 0&&d(t,r.next,!0),n.tags.length&&(n.before=n.tags[n.tags.length-1].nextElementSibling,n.flush()),t.insert(``,r,n,!1)},[t,r.name]),null});function re(){return o([...arguments])}var C=JSON.parse(`[{"id":"stock-001","name":"PER","category":"주식","description":"주가를 주당순이익(EPS)으로 나눈 지표. 주식의 가격 수준을 가늠하는 대표적 밸류에이션 배수.","aliases":["주가수익비율","p/e","pe"],"example":"삼성전자의 PER이 15배로 업종 평균보다 낮게 거래되고 있다."},{"id":"stock-002","name":"PBR","category":"주식","description":"주가를 주당순자산(BPS)으로 나눈 지표. 1 미만이면 청산가치 이하로 평가된 것.","aliases":["주가순자산비율","p/b"],"example":"코스피 평균 PBR이 0.9배로 청산가치 이하 수준에 머물고 있다."},{"id":"stock-003","name":"EPS","category":"주식","description":"당기순이익을 발행주식 수로 나눈 주당순이익.","aliases":["주당순이익"],"example":"2분기 EPS가 전년 동기 대비 12% 증가했다."},{"id":"stock-004","name":"ROE","category":"주식","description":"순이익을 자기자본으로 나눈 자기자본이익률. 주주가 투자한 자본 대비 수익성을 나타냄.","aliases":["자기자본이익률"],"example":"ROE 20%를 달성하며 업계 최고 수준의 수익성을 기록했다."},{"id":"stock-005","name":"ROA","category":"주식","description":"순이익을 총자산으로 나눈 총자산이익률.","aliases":["총자산이익률"],"example":"은행의 ROA가 0.5%로 전년 대비 개선됐다."},{"id":"stock-006","name":"BPS","category":"주식","description":"총자산에서 총부채를 뺀 순자산을 발행주식 수로 나눈 주당순자산.","aliases":["주당순자산"],"example":"BPS 대비 주가가 1.2배 수준에서 거래되고 있다."},{"id":"stock-007","name":"시가총액","category":"주식","description":"주가에 상장 주식 수를 곱한 값. 기업의 시장가치를 나타냄.","aliases":["시총","market cap","marketcap"],"example":"삼성전자의 시가총액이 400조 원을 돌파했다."},{"id":"stock-008","name":"배당수익률","category":"주식","description":"주당배당금을 주가로 나눈 비율.","aliases":["배당률","dividend yield"],"example":"배당수익률 4%를 기록하며 고배당주로 주목받고 있다."},{"id":"stock-009","name":"공매도","category":"주식","description":"보유하지 않은 주식을 빌려 매도하는 투자 기법. 주가 하락을 예상할 때 사용.","aliases":["short selling","short"],"example":"공매도 잔고가 급증하며 주가 하락 압력이 커지고 있다."},{"id":"stock-010","name":"상한가","category":"주식","description":"하루 동안 주가가 오를 수 있는 최대 한도(한국 30%)에 도달한 상태.","aliases":["upper limit"],"example":"호재 발표 직후 해당 종목은 상한가를 기록했다."},{"id":"stock-011","name":"하한가","category":"주식","description":"하루 동안 주가가 내릴 수 있는 최대 한도(한국 −30%)에 도달한 상태.","aliases":["lower limit"],"example":"어닝쇼크 발표 다음 날 해당 종목은 하한가로 직행했다."},{"id":"stock-012","name":"거래량","category":"주식","description":"특정 기간 동안 거래된 주식 수.","aliases":["volume","trading volume"],"example":"평소의 10배에 달하는 거래량이 쏟아지며 시장의 관심이 집중됐다."},{"id":"bond-001","name":"국채","category":"채권","description":"중앙정부가 발행하는 채권. 신용등급이 높아 안전 자산으로 분류.","aliases":["government bond","treasury bond"],"example":"10년물 국채 금리가 연 4%를 돌파했다."},{"id":"bond-002","name":"회사채","category":"채권","description":"기업이 자금 조달을 위해 발행하는 채권.","aliases":["corporate bond"],"example":"신용등급 A급 회사채 발행이 올해 크게 증가했다."},{"id":"bond-003","name":"채권수익률","category":"채권","description":"채권을 만기까지 보유할 때 얻는 연간 수익률(YTM).","aliases":["yield","ytm","만기수익률"],"example":"채권수익률이 상승하면 채권 가격은 하락한다."},{"id":"bond-004","name":"듀레이션","category":"채권","description":"채권 현금흐름의 가중평균 만기. 금리 변동에 대한 채권 가격 민감도를 나타냄.","aliases":["duration"],"example":"듀레이션이 길수록 금리 변동에 따른 채권 가격 변동이 크다."},{"id":"bond-005","name":"신용등급","category":"채권","description":"채무자의 채무 이행 능력을 평가한 등급.","aliases":["credit rating","rating"],"example":"무디스가 해당 기업의 신용등급을 BBB로 하향 조정했다."},{"id":"bond-006","name":"액면가","category":"채권","description":"채권 발행 시 표시되는 기준 금액. 만기 시 상환되는 금액.","aliases":["face value","par value","par"],"example":"주식 액면가가 5,000원에서 500원으로 분할됐다."},{"id":"bond-007","name":"쿠폰금리","category":"채권","description":"채권의 액면가에 대해 지급하는 연간 이자율.","aliases":["coupon rate","coupon"],"example":"연 3% 쿠폰금리의 5년 만기 회사채를 발행했다."},{"id":"bond-008","name":"역전된 수익률 곡선","category":"채권","description":"단기 금리가 장기 금리보다 높아지는 현상. 경기 침체의 선행 신호로 여겨짐.","aliases":["inverted yield curve","yield curve inversion"],"example":"미국 2년-10년 국채 수익률 곡선이 역전되며 경기침체 우려가 높아졌다."},{"id":"macro-001","name":"GDP","category":"거시경제","description":"일정 기간 한 나라 안에서 생산된 모든 재화·서비스의 시장 가치 합계.","aliases":["국내총생산","gross domestic product"],"example":"지난해 GDP 성장률이 2.5%로 잠정 집계됐다."},{"id":"macro-002","name":"기준금리","category":"거시경제","description":"중앙은행이 설정하는 정책 금리. 시중 금리의 기준이 됨.","aliases":["base rate","key rate","정책금리"],"example":"한국은행이 기준금리를 3.5%로 동결했다."},{"id":"macro-003","name":"인플레이션","category":"거시경제","description":"물가 수준이 지속적으로 상승하는 현상.","aliases":["inflation","물가상승"],"example":"소비자물가 상승률이 5%를 넘어서며 인플레이션 우려가 커지고 있다."},{"id":"macro-004","name":"디플레이션","category":"거시경제","description":"물가 수준이 지속적으로 하락하는 현상.","aliases":["deflation","물가하락"],"example":"물가가 3개월 연속 하락하며 디플레이션 진입 여부에 관심이 쏠린다."},{"id":"macro-005","name":"CPI","category":"거시경제","description":"소비자가 구매하는 재화·서비스의 가격 변동을 측정하는 소비자물가지수.","aliases":["소비자물가지수","consumer price index"],"example":"지난달 CPI가 전년 동월 대비 3.2% 상승했다."},{"id":"macro-006","name":"PPI","category":"거시경제","description":"생산자가 판매하는 재화·서비스의 가격 변동을 측정하는 생산자물가지수.","aliases":["생산자물가지수","producer price index"],"example":"PPI 상승세가 둔화되며 향후 소비자물가 안정화 기대감이 커졌다."},{"id":"macro-007","name":"환율","category":"거시경제","description":"자국 통화 한 단위와 교환되는 외국 통화의 양.","aliases":["exchange rate"],"example":"원달러 환율이 1,400원을 돌파하며 수입 물가 상승 우려가 높아졌다."},{"id":"macro-008","name":"경상수지","category":"거시경제","description":"상품·서비스 수출입, 소득, 이전 거래를 포함한 국제 거래 수지.","aliases":["current account"],"example":"경상수지가 3개월 연속 흑자를 기록했다."},{"id":"macro-009","name":"베이시스포인트","category":"거시경제","description":"금리나 수익률 변화를 나타내는 단위. 1bp = 0.01%p.","aliases":["bp","bps","basis point","basis points"],"example":"한국은행이 기준금리를 25bp 인하했다."},{"id":"macro-010","name":"양적완화","category":"거시경제","description":"중앙은행이 채권 등을 매입해 시중에 유동성을 공급하는 비전통적 통화정책.","aliases":["QE","quantitative easing"],"example":"연준이 양적완화 프로그램을 통해 시장에 유동성을 공급했다."},{"id":"deriv-001","name":"선물","category":"파생상품","description":"미래 특정 시점에 사전에 정한 가격으로 자산을 사고팔기로 약정한 계약.","aliases":["futures"],"example":"코스피200 선물 가격이 현물보다 높은 콘탱고 상태다."},{"id":"deriv-002","name":"콜옵션","category":"파생상품","description":"특정 가격(행사가)에 자산을 매수할 수 있는 권리.","aliases":["call option","call"],"example":"주가 상승을 예상하고 콜옵션을 매수했다."},{"id":"deriv-003","name":"풋옵션","category":"파생상품","description":"특정 가격(행사가)에 자산을 매도할 수 있는 권리.","aliases":["put option","put"],"example":"시장 하락을 대비해 풋옵션을 매입했다."},{"id":"deriv-004","name":"스왑","category":"파생상품","description":"두 당사자가 미래 현금 흐름을 교환하기로 하는 계약.","aliases":["swap"],"example":"변동금리를 고정금리로 교환하는 금리스왑 계약을 체결했다."},{"id":"deriv-005","name":"변동성","category":"파생상품","description":"자산 가격의 변동 폭을 나타내는 지표. 옵션 가격 산정의 핵심 변수.","aliases":["volatility","vol"],"example":"VIX가 급등하며 시장 변동성이 크게 높아졌다."},{"id":"deriv-006","name":"VIX","category":"파생상품","description":"S&P 500 옵션 가격에서 도출된 향후 30일 예상 변동성 지수. '공포지수'라고도 불림.","aliases":["공포지수","fear index"],"example":"VIX가 30을 넘어서며 투자자들의 공포 심리가 극에 달했다."},{"id":"deriv-007","name":"레버리지","category":"파생상품","description":"차입 자금을 이용해 실제 투자 금액 이상의 포지션을 취하는 것.","aliases":["leverage"],"example":"3배 레버리지 ETF를 활용해 수익률을 극대화했다."},{"id":"deriv-008","name":"마진콜","category":"파생상품","description":"레버리지 포지션에서 손실이 커져 증거금을 추가로 납부해야 하는 상황.","aliases":["margin call"],"example":"주가 급락으로 마진콜이 발생해 강제 청산이 이루어졌다."},{"id":"realty-001","name":"LTV","category":"부동산","description":"담보 가치 대비 대출 가능 금액의 비율.","aliases":["주택담보대출비율","loan to value"],"example":"LTV 70% 규제로 집값의 30%는 자기 자금으로 마련해야 한다."},{"id":"realty-002","name":"DSR","category":"부동산","description":"연간 총부채 원리금 상환액을 연소득으로 나눈 비율.","aliases":["총부채원리금상환비율","debt service ratio"],"example":"DSR 40% 규제로 연소득 5천만 원인 경우 연간 원리금 상환액이 2천만 원을 넘길 수 없다."},{"id":"realty-003","name":"DTI","category":"부동산","description":"연간 총부채 이자 상환액을 연소득으로 나눈 비율.","aliases":["총부채상환비율"],"example":"DTI 기준을 초과해 추가 대출이 제한됐다."},{"id":"realty-004","name":"전세","category":"부동산","description":"임차인이 보증금을 맡기고 계약 기간 동안 무상으로 거주하는 한국 고유의 임대 방식.","aliases":["jeonse","전세계약"],"example":"전세 보증금이 2년 만에 1억 원 올랐다."},{"id":"realty-005","name":"청약","category":"부동산","description":"신규 분양 아파트 입주권을 신청하는 절차.","aliases":["housing subscription"],"example":"청약 경쟁률이 500대 1을 넘어서며 로또 청약으로 불렸다."},{"id":"realty-006","name":"용적률","category":"부동산","description":"대지면적 대비 건물 연면적의 비율. 개발 밀도를 결정하는 핵심 규제.","aliases":["floor area ratio","far"],"example":"용적률 250%를 적용해 최대 25층까지 건축할 수 있다."},{"id":"realty-007","name":"재건축","category":"부동산","description":"노후 아파트·건물을 허물고 새로 짓는 정비 사업.","aliases":["reconstruction"],"example":"안전진단을 통과한 단지가 재건축 사업을 본격 추진한다."},{"id":"realty-008","name":"분양가상한제","category":"부동산","description":"신규 분양 아파트의 분양 가격에 상한선을 두는 제도.","aliases":["price ceiling","분양가규제"],"example":"분양가상한제 적용 지역에서는 시세보다 낮은 가격에 신규 분양이 이루어진다."},{"id":"acct-001","name":"매출액","category":"회계","description":"기업이 주된 영업활동으로 벌어들인 총수입.","aliases":["매출","revenue","sales"],"example":"3분기 매출액이 전년 동기 대비 15% 성장했다."},{"id":"acct-002","name":"영업이익","category":"회계","description":"매출에서 매출원가와 판관비를 뺀 이익.","aliases":["operating income","operating profit","EBIT"],"example":"원가 절감 노력으로 영업이익률이 10%를 회복했다."},{"id":"acct-003","name":"순이익","category":"회계","description":"모든 비용과 세금을 제한 후 남은 최종 이익.","aliases":["당기순이익","net income","net profit"],"example":"일회성 비용 제외 시 순이익은 전년 대비 20% 증가했다."},{"id":"acct-004","name":"EBITDA","category":"회계","description":"이자·세금·감가상각 전 이익. 기업의 순수 영업 현금 창출력을 나타냄.","aliases":[],"example":"EBITDA 기준으로는 흑자를 유지하고 있다."},{"id":"acct-005","name":"부채비율","category":"회계","description":"총부채를 자기자본으로 나눈 비율. 기업의 재무 건전성 지표.","aliases":["debt ratio","debt-to-equity","d/e"],"example":"부채비율 200%를 초과하며 재무 건전성 우려가 제기됐다."},{"id":"acct-006","name":"유동비율","category":"회계","description":"유동자산을 유동부채로 나눈 비율. 단기 채무 상환 능력을 나타냄.","aliases":["current ratio"],"example":"유동비율이 150%로 단기 채무 이행 능력이 양호하다."},{"id":"acct-007","name":"영업현금흐름","category":"회계","description":"영업활동에서 실제로 발생한 현금의 유입·유출.","aliases":["operating cash flow","OCF"],"example":"영업현금흐름이 꾸준히 증가하며 현금 창출 능력을 입증했다."},{"id":"acct-008","name":"자본잠식","category":"회계","description":"누적 손실이 자본금을 잠식한 상태. 완전 자본잠식 시 상장폐지 위기.","aliases":["capital impairment","capital erosion"],"example":"누적 적자로 자본금이 잠식되어 상장폐지 심사 대상에 올랐다."}]`),w=new class{lookup;constructor(){this.lookup=new Map;for(let e of C){this.lookup.set(e.name.toLowerCase(),e);for(let t of e.aliases)this.lookup.set(t.toLowerCase(),e)}}match(e){return this.lookup.get(e.trim().toLowerCase())}get keys(){return new Set(this.lookup.keys())}};function T(e,t){let n=document.createElement(`span`);return n.setAttribute(`data-light`,t.name),n.setAttribute(`data-light-category`,t.category),n.textContent=e,n}function E(e){return e.closest(`[data-light]`)!==null}var D=new Set([`SCRIPT`,`STYLE`,`TEXTAREA`,`INPUT`,`NOSCRIPT`,`SELECT`,`CODE`,`PRE`]);function O(){let e=[...w.keys].sort((e,t)=>t.length-e.length).map(e=>e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`));return RegExp(`(?<![a-zA-Z])(${e.join(`|`)})(?![a-zA-Z])`,`gi`)}var ie=O();function ae(e){let t=e;for(;t;){if(D.has(t.tagName))return!0;t=t.parentElement}return!1}function oe(e){return document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode(e){let t=e.parentElement;return!t||ae(t)||E(t)?NodeFilter.FILTER_REJECT:e.textContent?.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}})}function se(e,t){let n=(e.textContent??``).split(ie);if(n.length===1)return null;let r=document.createDocumentFragment();for(let e of n){if(!e)continue;let n=w.match(e);n?(r.appendChild(T(e,n)),t.set(n.name,n)):r.appendChild(document.createTextNode(e))}return r}function ce(e=document.body){let t=oe(e),n=[],r=new Map,i;for(;i=t.nextNode();){let e=se(i,r);e&&n.push({node:i,fragment:e})}for(let{node:e,fragment:t}of n)e.parentNode?.replaceChild(t,e);return[...r.values()]}var k=(0,b.createContext)(null);function A(){let e=(0,b.useContext)(k);if(!e)throw Error(`useSettings must be used within SettingsContext.Provider`);return e}var le=/^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|popover|popoverTarget|popoverTargetAction|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,ue=v(function(e){return le.test(e)||e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)<91}),de=function(e){return e!==`theme`},j=function(e){return typeof e==`string`&&e.charCodeAt(0)>96?ue:de},M=function(e,t,n){var r;if(t){var i=t.shouldForwardProp;r=e.__emotion_forwardProp&&i?function(t){return e.__emotion_forwardProp(t)&&i(t)}:i}return typeof r!=`function`&&n&&(r=e.__emotion_forwardProp),r},fe=function(e){var t=e.cache,n=e.serialized,r=e.isStringTag;return c(t,n,r),_(function(){return d(t,n,r)}),null},pe=function e(t,n){var r=t.__emotion_real===t,i=r&&t.__emotion_base||t,a,s;n!==void 0&&(a=n.label,s=n.target);var c=M(t,n,r),l=c||j(i),d=!l(`as`);return function(){var f=arguments,m=r&&t.__emotion_styles!==void 0?t.__emotion_styles.slice(0):[];if(a!==void 0&&m.push(`label:`+a+`;`),f[0]==null||f[0].raw===void 0)m.push.apply(m,f);else{var h=f[0];m.push(h[0]);for(var g=f.length,_=1;_<g;_++)m.push(f[_],h[_])}var v=u(function(e,t,n){var r=d&&e.as||i,a=``,u=[],f=e;if(e.theme==null){for(var h in f={},e)f[h]=e[h];f.theme=b.useContext(p)}typeof e.className==`string`?a=ee(t.registered,u,e.className):e.className!=null&&(a=e.className+` `);var g=o(m.concat(u),t.registered,f);a+=t.key+`-`+g.name,s!==void 0&&(a+=` `+s);var _=d&&c===void 0?j(r):l,v={};for(var y in e)d&&y===`as`||_(y)&&(v[y]=e[y]);return v.className=a,n&&(v.ref=n),b.createElement(b.Fragment,null,b.createElement(fe,{cache:t,serialized:g,isStringTag:typeof r==`string`}),b.createElement(r,v))});return v.displayName=a===void 0?`Styled(`+(typeof i==`string`?i:i.displayName||i.name||`Component`)+`)`:a,v.defaultProps=t.defaultProps,v.__emotion_real=v,v.__emotion_base=i,v.__emotion_styles=m,v.__emotion_forwardProp=c,Object.defineProperty(v,"toString",{value:function(){return`.`+s}}),v.withComponent=function(t,r){return e(t,S({},n,r,{shouldForwardProp:M(v,r,!0)})).apply(void 0,m)},v}},me=`a.abbr.address.area.article.aside.audio.b.base.bdi.bdo.big.blockquote.body.br.button.canvas.caption.cite.code.col.colgroup.data.datalist.dd.del.details.dfn.dialog.div.dl.dt.em.embed.fieldset.figcaption.figure.footer.form.h1.h2.h3.h4.h5.h6.head.header.hgroup.hr.html.i.iframe.img.input.ins.kbd.keygen.label.legend.li.link.main.map.mark.marquee.menu.menuitem.meta.meter.nav.noscript.object.ol.optgroup.option.output.p.param.picture.pre.progress.q.rp.rt.ruby.s.samp.script.section.select.small.source.span.strong.style.sub.summary.sup.table.tbody.td.textarea.tfoot.th.thead.time.title.tr.track.u.ul.var.video.wbr.circle.clipPath.defs.ellipse.foreignObject.g.image.line.linearGradient.mask.path.pattern.polygon.polyline.radialGradient.rect.stop.svg.text.tspan`.split(`.`),N=pe.bind(null);me.forEach(function(e){N[e]=N(e)});var P={blue50:`#eff6ff`,blue100:`#c8e0ff`,blue300:`#7eb1f3`,blue500:`#1779e1`,blue700:`#004fa7`,neutral0:`#fbfcfd`,neutral100:`#edeef0`,neutral200:`#d6d7da`,neutral400:`#8d8f92`,neutral600:`#535559`,neutral900:`#191b1d`,border:`#e6e8ea`,textPrimary:`#191b1d`,textBody:`#535559`,textCaption:`#8d8f92`,textMuted:`#606369`,highlight:{bg:`rgba(200, 224, 255, 0.35)`,border:`#1779e1`},category:{주식:`#64a1ee`,채권:`#00b5c5`,거시경제:`#ab8be3`,파생상품:`#e47d6d`,부동산:`#67b36a`,회계:`#c3972a`}},F={base:`'Pretendard', -apple-system, BlinkMacSystemFont, sans-serif`};F.base,P.textPrimary,F.base,P.textPrimary,F.base,P.textBody,F.base,P.textCaption;var I={sm:`10px`,md:`16px`,lg:`22px`,full:`99px`},L={soft:`0px 4px 8px rgba(20, 30, 60, 0.08)`},R={1:`4px`,2:`8px`,3:`12px`,4:`16px`,5:`20px`,6:`24px`,8:`32px`,10:`40px`},z=8,B=8,V=280,H=8,he=N.div`
  position: fixed;
  pointer-events: none;
  z-index: 2147483647;
  width: ${V}px;
  background: #fff;
  border-radius: ${I.sm};
  box-shadow: 0 4px 20px rgba(20, 30, 60, 0.16);
  transition: opacity 0.12s ease;
`,ge=N.div`
  position: absolute;
  left: ${e=>e.$x}px;
  width: 0;
  height: 0;
  border-left: ${H}px solid transparent;
  border-right: ${H}px solid transparent;
  ${e=>e.$flipped?`top: -${H}px; border-bottom: ${H}px solid #fff;`:`bottom: -${H}px; border-top: ${H}px solid #fff;`}
`,_e=N.div`
  display: flex;
  align-items: center;
  gap: ${R[2]};
  padding: ${R[4]} ${R[4]} ${R[2]};
`,ve=N.span`
  font-family: ${F.base};
  font-size: 14px;
  font-weight: 700;
  color: ${P.textPrimary};
  line-height: 1.4;
`,ye=N.span`
  font-family: ${F.base};
  font-size: 11px;
  font-weight: 600;
  color: ${e=>P.category[e.$cat]};
  background: ${e=>P.category[e.$cat]}22;
  border-radius: ${I.full};
  padding: 2px 8px;
  white-space: nowrap;
  flex-shrink: 0;
`,be=N.p`
  font-family: ${F.base};
  font-size: 13px;
  font-weight: 400;
  line-height: 1.6;
  color: ${P.textBody};
  margin: 0;
  padding: 0 ${R[4]} ${R[4]};
`,xe=N.div`
  border-top: 1px solid ${P.neutral100};
  padding: ${R[3]} ${R[4]} ${R[4]};
`,Se=N.div`
  font-family: ${F.base};
  font-size: 11px;
  font-weight: 600;
  color: ${P.textCaption};
  margin-bottom: ${R[1]};
`,Ce=N.div`
  font-family: ${F.base};
  font-size: 12px;
  line-height: 1.6;
  color: ${P.textBody};
`;function we({term:e,anchorRect:t}){let n=(0,b.useRef)(null),[r,i]=(0,b.useState)({x:t.left,y:t.bottom+z,caretX:H*2,flipped:!1,opacity:0});return(0,b.useLayoutEffect)(()=>{let e=n.current;if(!e)return;let r=e.offsetHeight,a=t.top-r-H-z,o=!1;a<B&&(a=t.bottom+H+z,o=!0);let s=t.left,c=window.innerWidth-V-B;s=Math.min(Math.max(B,s),c);let l=t.left+t.width/2,u=Math.min(Math.max(H*2,l-s-H),V-H*4);i({x:s,y:a,caretX:u,flipped:o,opacity:1})},[t]),m(he,{ref:n,style:{left:r.x,top:r.y,opacity:r.opacity},children:[f(ge,{$x:r.caretX,$flipped:r.flipped}),m(_e,{children:[f(ve,{children:e.name}),f(ye,{$cat:e.category,children:e.category})]}),f(be,{children:e.description}),e.example&&m(xe,{children:[f(Se,{children:`예시`}),m(Ce,{children:[`"`,e.example,`"`]})]})]})}function Te(){let{settings:e}=A(),[t,n]=(0,b.useState)(null),r=(0,b.useRef)(null),i=(0,b.useCallback)(()=>{r.current&&=(clearTimeout(r.current),null)},[]),a=(0,b.useCallback)(t=>{let a=t.target.closest(`[data-light]`);if(!a)return;let o=a.getAttribute(`data-light`)??``,s=w.match(o);s&&(!e.enabled||!e.categories[s.category]||(i(),r.current=setTimeout(()=>{n({term:s,anchorRect:a.getBoundingClientRect()})},150)))},[i,e]),o=(0,b.useCallback)(e=>{e.target.closest(`[data-light]`)&&(i(),n(null))},[i]);return(0,b.useEffect)(()=>(document.addEventListener(`mouseover`,a),document.addEventListener(`mouseout`,o),()=>{document.removeEventListener(`mouseover`,a),document.removeEventListener(`mouseout`,o),i()}),[a,o,i]),f(g,{children:t&&f(we,{term:t.term,anchorRect:t.anchorRect})})}var Ee=N.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${R[3]};
`,De=N.span`
  font-family: ${F.base};
  font-size: 12px;
  font-weight: 600;
  color: ${P.textCaption};
`,Oe=N.p`
  font-family: ${F.base};
  font-size: 13px;
  color: ${P.textCaption};
  text-align: center;
  padding: ${R[4]} 0;
`,ke=N.ul`
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: ${R[1]};
`,Ae=N.li`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${R[2]} 0;
  border-bottom: 1px solid ${P.neutral100};

  &:last-child {
    border-bottom: none;
  }
`,je=N.span`
  font-family: ${F.base};
  font-size: 14px;
  font-weight: 500;
  color: ${P.textPrimary};
`,Me=N.span`
  font-family: ${F.base};
  font-size: 11px;
  font-weight: 600;
  color: ${e=>P.category[e.$cat]};
  background: ${e=>P.category[e.$cat]}22;
  border-radius: 99px;
  padding: 2px 8px;
  white-space: nowrap;
  flex-shrink: 0;
`;function Ne(){let{detectedTerms:e}=A();return m(`div`,{children:[f(Ee,{children:m(De,{children:[`저장된 키워드 · `,e.length]})}),e.length===0?f(Oe,{children:`감지된 키워드가 없습니다.`}):f(ke,{children:e.map(e=>m(Ae,{children:[f(je,{children:e.name}),f(Me,{$cat:e.category,children:e.category})]},e.id))})]})}var Pe=[`주식`,`채권`,`거시경제`,`파생상품`,`부동산`,`회계`],Fe=[{hex:`#1779e1`,label:`파랑`},{hex:`#67b36a`,label:`초록`},{hex:`#e47d6d`,label:`주황`},{hex:`#9b5de5`,label:`보라`},{hex:`#e5698b`,label:`핑크`},{hex:`#e53935`,label:`빨강`}],Ie=N.button`
  position: relative;
  width: 38px;
  height: 22px;
  border-radius: ${I.full};
  border: none;
  cursor: pointer;
  background: ${e=>e.$on?P.blue500:P.neutral200};
  transition: background 0.2s ease;
  flex-shrink: 0;
`,Le=N.span`
  position: absolute;
  top: 4px;
  left: ${e=>e.$on?`18px`:`4px`};
  width: 14px;
  height: 14px;
  border-radius: ${I.full};
  background: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  transition: left 0.2s ease;
`;function U({on:e,onChange:t}){return f(Ie,{$on:e,onClick:()=>t(!e),children:f(Le,{$on:e})})}var W=N.div`
  & + & {
    margin-top: ${R[4]};
    padding-top: ${R[4]};
    border-top: 1px solid ${P.neutral100};
  }
`,G=N.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${R[2]} 0;
`,K=N.span`
  font-family: ${F.base};
  font-size: 14px;
  font-weight: 500;
  color: ${P.textPrimary};
  display: flex;
  align-items: center;
  gap: ${R[2]};
`,Re=N.span`
  width: 8px;
  height: 8px;
  border-radius: ${I.full};
  background: ${e=>P.category[e.$cat]};
  display: inline-block;
  flex-shrink: 0;
`,q=N.div`
  font-family: ${F.base};
  font-size: 11px;
  font-weight: 600;
  color: ${P.textCaption};
  margin-bottom: ${R[1]};
`,ze=N.div`
  display: flex;
  gap: ${R[2]};
  margin-top: ${R[2]};
  flex-wrap: wrap;
`,Be=N.button`
  width: 22px;
  height: 22px;
  border-radius: ${I.full};
  background: ${e=>e.$hex};
  border: 2px solid ${e=>e.$selected?P.neutral900:`transparent`};
  cursor: pointer;
  outline: ${e=>e.$selected?`2px solid ${e.$hex}`:`none`};
  outline-offset: 2px;
  flex-shrink: 0;
  transition: outline 0.15s ease, border 0.15s ease;
`;function Ve(){let{settings:e,setSettings:t}=A(),n=e=>t(t=>({...t,enabled:e})),r=(e,n)=>t(t=>({...t,categories:{...t.categories,[e]:n}})),i=e=>t(t=>({...t,color:e}));return m(`div`,{children:[f(W,{children:m(G,{children:[f(K,{children:`전체 사용`}),f(U,{on:e.enabled,onChange:n})]})}),m(W,{children:[f(q,{children:`카테고리`}),Pe.map(t=>m(G,{children:[m(K,{children:[f(Re,{$cat:t}),t]}),f(U,{on:e.categories[t],onChange:e=>r(t,e)})]},t))]}),m(W,{children:[f(q,{children:`하이라이트 색상`}),f(ze,{children:Fe.map(({hex:t,label:n})=>f(Be,{$hex:t,$selected:e.color===t,onClick:()=>i(t)},n))})]})]})}var He=260,Ue=24,J=24,We=N.button`
  position: fixed;
  bottom: ${Ue}px;
  right: ${J}px;
  width: 50px;
  height: 50px;
  border-radius: ${I.full};
  background: ${P.blue500};
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(23, 121, 225, 0.4);
  font-family: ${F.base};
  font-size: 18px;
  font-weight: 700;
  color: #fff;
  z-index: 2147483646;
  transition: transform 0.15s ease, box-shadow 0.15s ease;

  &:hover {
    transform: scale(1.06);
    box-shadow: 0 6px 16px rgba(23, 121, 225, 0.5);
  }
`,Ge=N.div`
  position: fixed;
  bottom: ${86}px;
  right: ${J}px;
  width: ${He}px;
  background: #fff;
  border-radius: ${I.md};
  box-shadow: 0 8px 32px rgba(20, 30, 60, 0.18);
  z-index: 2147483646;
  overflow: hidden;
`,Y=N.div`
  display: flex;
  padding: ${R[2]};
  background: ${P.neutral100};
  gap: ${R[1]};
`,X=N.button`
  flex: 1;
  padding: ${R[2]} 0;
  border: none;
  cursor: pointer;
  border-radius: ${I.sm};
  font-family: ${F.base};
  font-size: 14px;
  font-weight: 500;
  transition: background 0.12s ease;
  background: ${e=>e.$active?`#fff`:`transparent`};
  color: ${e=>e.$active?P.textPrimary:P.textCaption};
  box-shadow: ${e=>e.$active?L.soft:`none`};
`,Ke=N.div`
  padding: ${R[3]} ${R[4]};
  min-height: 120px;
  max-height: 360px;
  overflow-y: auto;
`;function qe({detectedCount:e}){let[t,n]=(0,b.useState)(!1),[r,i]=(0,b.useState)(`note`),{settings:a}=A();return m(g,{children:[t&&m(Ge,{children:[m(Y,{children:[f(X,{$active:r===`note`,onClick:()=>i(`note`),children:`내 노트`}),f(X,{$active:r===`settings`,onClick:()=>i(`settings`),children:`설정`})]}),f(Ke,{children:f(r===`note`?Ne:Ve,{})})]}),f(We,{onClick:()=>n(e=>!e),children:a.enabled?e:`—`})]})}function Je(e,t){let n=e.replace(`#`,``);return`rgba(${parseInt(n.slice(0,2),16)}, ${parseInt(n.slice(2,4),16)}, ${parseInt(n.slice(4,6),16)}, ${t})`}function Ye(e){let t=Je(e.color,.2),n=e.color;return[e.enabled?`[data-light] {
        background-color: ${t};
        border-bottom: 1.5px dashed ${n};
        border-radius: 2px;
        padding: 1px 3px;
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
        cursor: default;
      }`:`[data-light] {
        background-color: transparent;
        border-bottom: none;
        cursor: default;
      }`,...Object.entries(e.categories).filter(([,e])=>!e).map(([e])=>`[data-light-category="${e}"] {
        background-color: transparent !important;
        border-bottom: none !important;
      }`)].join(`
`)}function Xe(e){(0,b.useEffect)(()=>{let t=document.getElementById(`light-styles`);t&&(t.textContent=Ye(e))},[e])}var Z={enabled:!0,categories:{주식:!0,채권:!0,거시경제:!0,파생상품:!0,부동산:!0,회계:!0},color:`#1779e1`},Q=`light_settings`;function Ze(){let[e,t]=(0,b.useState)(Z),n=(0,b.useRef)(!1);return(0,b.useEffect)(()=>{chrome.storage.sync.get(Q,e=>{e[Q]&&t(e[Q]),n.current=!0})},[]),(0,b.useEffect)(()=>{n.current&&chrome.storage.sync.set({[Q]:e})},[e]),[e,t]}var Qe=re`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
`;function $e({detectedTerms:e}){let{settings:t}=A();return Xe(t),m(g,{children:[f(ne,{styles:Qe}),f(Te,{}),f(qe,{detectedCount:e.length})]})}function et({detectedTerms:e}){let[t,n]=Ze();return f(k.Provider,{value:{settings:t,setSettings:n,detectedTerms:e},children:f($e,{detectedTerms:e})})}function tt(){if(document.getElementById(`light-styles`))return;let e=document.createElement(`style`);e.id=`light-styles`;let t=Z.color.replace(`#`,``);e.textContent=`
    [data-light] {
      background-color: rgba(${parseInt(t.slice(0,2),16)}, ${parseInt(t.slice(2,4),16)}, ${parseInt(t.slice(4,6),16)}, 0.2);
      border-bottom: 1.5px dashed ${Z.color};
      border-radius: 2px;
      padding: 1px 3px;
      box-decoration-break: clone;
      -webkit-box-decoration-break: clone;
      cursor: default;
    }
  `,document.head.appendChild(e)}function $(){if(document.getElementById(`light-root`))return;tt();let e=document.createElement(`div`);e.id=`light-root`,document.body.appendChild(e);let n=e.attachShadow({mode:`open`}),r=document.createElement(`div`);n.appendChild(r);let i=t({key:`light`,container:n}),a=ce();x.createRoot(r).render(f(b.StrictMode,{children:f(l,{value:i,children:f(et,{detectedTerms:a})})}))}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,$):$();